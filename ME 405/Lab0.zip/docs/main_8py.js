var main_8py =
[
    [ "led_brightness", "main_8py.html#a0787b716fe8f91980319e58103885403", null ],
    [ "led_setup", "main_8py.html#a6ef5ac3570ce2c3589413b978e830e1d", null ],
    [ "ch2", "main_8py.html#a7ac7690ca90866fea4a3fd53c39e168f", null ],
    [ "t0", "main_8py.html#a40b697d790636df39ccd298d72b767a1", null ],
    [ "tcur", "main_8py.html#a3f6fda73da6118b66d1d84a1561cb61d", null ],
    [ "tdif", "main_8py.html#a625f6a7787625b7189c42a567791f311", null ]
];