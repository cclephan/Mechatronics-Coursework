var searchData=
[
  ['led_5fbrightness_0',['led_brightness',['../main_8py.html#a0787b716fe8f91980319e58103885403',1,'main']]],
  ['led_5fsetup_1',['led_setup',['../main_8py.html#a6ef5ac3570ce2c3589413b978e830e1d',1,'main']]]
];
