var searchData=
[
  ['t0_0',['t0',['../main_8py.html#a40b697d790636df39ccd298d72b767a1',1,'main']]],
  ['tcur_1',['tcur',['../main_8py.html#a3f6fda73da6118b66d1d84a1561cb61d',1,'main']]],
  ['tdif_2',['tdif',['../main_8py.html#a625f6a7787625b7189c42a567791f311',1,'main']]]
];
